create
    definer = root@localhost procedure get_distinct_people_older_than(IN a tinyint)
begin
  select * from kda_test.users
  where Age > a;
end;

