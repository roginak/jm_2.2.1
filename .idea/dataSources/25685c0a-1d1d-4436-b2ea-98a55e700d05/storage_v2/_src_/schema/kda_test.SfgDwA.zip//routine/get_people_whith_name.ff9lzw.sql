create
    definer = root@localhost procedure get_people_whith_name(IN a char(20))
begin
  select * from kda_test.users
  where Name = a;
end;

